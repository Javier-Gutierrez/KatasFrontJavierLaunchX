# CSS

## Aquí le ponemos estilo a todas nuestras páginas

Les dejé unos programas con los ejemplos que estuvimos viendo en los diferentes lives.

- [Selectores](./programas/1.-selectores.html)
- [Colores](./programas/2.-colores.css)
- [Fondos](./programas/3.-fondos.css)
- [Textos](./programas/4.-textos.css)

## Práctica

[Este es el link de la práctica](./practica/README.md)
